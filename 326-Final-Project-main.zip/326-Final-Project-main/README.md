# Welcome Home!

#### This milestone report walks you through the proposal for our web app: Welcome Home. Our goal is to curate a relaxing, useful, and thoughtful organizational aid. As college students, we know how overwhelming it can be to even just fill out a planner with your tasks. Welcome Home aims to solve just that, with a visually appealing and customizable UI. 

## Command to run: 
#### npm start milestone-01 

## Overview
#### Project's vision, how it solves real-world problem.
## Application Parts
#### Three critical components of application.
## Data Requirements
#### Top types of data our application will handle
## Wire Frames
#### Sketches of four main screens of our application, their purpose and design rationale.
## Real-World Connection
#### More detailed explanation about how application solves real-world issue. 
## Integrative Experience
#### How this application represents our culminated academic and personal experiences. 
## Meet the Girls (About Us)
#### Background about each group member of Girls in STAM. 


